// scripts/importer_stub.ts
import fs from 'fs';
import { parse } from 'csv-parse/sync';
import { Client } from 'pg';

type Row = {
  canon: string;
  book_slug: string;
  book_name: string;
  source_code: string;
  language: string;
  chapter: number;
  verse: number;
  text: string;
};

async function db() {
  const client = new Client({ connectionString: process.env.DATABASE_URL });
  await client.connect();
  return client;
}

const DDL = `
CREATE TABLE IF NOT EXISTS book (
  id SERIAL PRIMARY KEY,
  slug TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chapter (
  id SERIAL PRIMARY KEY,
  book_id INT NOT NULL REFERENCES book(id) ON DELETE CASCADE,
  number INT NOT NULL,
  language TEXT NOT NULL DEFAULT 'en',
  source_code TEXT NOT NULL DEFAULT 'OSB',
  UNIQUE(book_id, number, language, source_code)
);
CREATE TABLE IF NOT EXISTS verse (
  id SERIAL PRIMARY KEY,
  chapter_id INT NOT NULL REFERENCES chapter(id) ON DELETE CASCADE,
  number INT NOT NULL,
  text TEXT NOT NULL,
  UNIQUE(chapter_id, number)
);
`;

async function upsertVerse(client: any, r: Row) {
  const b = await client.query(
    'INSERT INTO book(slug,name) VALUES($1,$2) ON CONFLICT(slug) DO UPDATE SET name=EXCLUDED.name RETURNING id',
    [r.book_slug, r.book_name]
  );
  const bookId = b.rows[0].id;

  const c = await client.query(
    `INSERT INTO chapter(book_id, number, language, source_code)
     VALUES($1,$2,$3,$4)
     ON CONFLICT(book_id, number, language, source_code) DO UPDATE SET language=EXCLUDED.language
     RETURNING id`,
    [bookId, Number(r.chapter), r.language || 'en', r.source_code || 'OSB']
  );
  const chapterId = c.rows[0].id;

  await client.query(
    `INSERT INTO verse(chapter_id, number, text)
     VALUES($1,$2,$3)
     ON CONFLICT(chapter_id, number) DO UPDATE SET text=EXCLUDED.text`,
    [chapterId, Number(r.verse), r.text]
  );
}

function isJSONL(p: string) { return p.toLowerCase().endsWith('.jsonl'); }
function isCSV(p: string)   { return p.toLowerCase().endsWith('.csv'); }

async function main() {
  const file = process.argv[2];
  if (!file) { console.error('Usage: ts-node scripts/importer_stub.ts <templates/all_books.jsonl|templates/verses_template.csv>'); process.exit(1); }
  const client = await db();
  await client.query(DDL);

  if (isJSONL(file)) {
    const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/).filter(Boolean);
    for (const line of lines) {
      const r = JSON.parse(line);
      await upsertVerse(client, r as Row);
    }
  } else if (isCSV(file)) {
    const content = fs.readFileSync(file, 'utf8');
    const rows = parse(content, { columns: true, skip_empty_lines: true });
    for (const r of rows as Row[]) await upsertVerse(client, r);
  } else {
    console.error('Unsupported file format. Use .jsonl or .csv');
  }

  await client.end();
  console.log('Import complete.');
}

main().catch(e=>{ console.error(e); process.exit(1); });
