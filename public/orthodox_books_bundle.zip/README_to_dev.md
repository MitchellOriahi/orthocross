# Orthodox Scripture Replication Bundle

What this is: a single package you can send to your developer so they can load **all OSB/LXX books** and the **Oriental/Tewahedo extras** into the app.

## Files
- books_manifest.json — Canon order and slugs (OSB_LXX + Tewahedo extras).
- templates/all_books.jsonl — JSONL template (one verse per line).
- templates/verses_template.csv — CSV template if you prefer spreadsheets.
- scripts/importer_stub.ts — Minimal TypeScript importer (CSV or JSONL) -> Postgres.

## How to use
1) Put your text lines into `templates/all_books.jsonl` (recommended) or into `verses_template.csv`.
2) Zip the folder and send to the developer (or give them the ZIP I included).
3) Developer runs the importer to populate the DB.

### JSONL rows (recommended)
{"canon":"OSB_LXX","book_slug":"genesis","book_name":"Genesis","source_code":"OSB","language":"en","chapter":1,"verse":1,"text":"In the beginning…"}
{"canon":"TEWAHEDO_81","book_slug":"1enoch","book_name":"1 Enoch","source_code":"RH_CHARLES","language":"en","chapter":1,"verse":1,"text":"The words of the blessing…"}

### CSV rows
canon,book_slug,book_name,source_code,language,chapter,verse,text
OSB_LXX,genesis,Genesis,OSB,en,1,1,In the beginning…
TEWAHEDO_81,1enoch,1 Enoch,RH_CHARLES,en,1,1,The words of the blessing…

### Notes
- **OSB text** requires a license. If you don't have one yet, you can use PD fallbacks (Brenton/LXX2012 for OT, WEB for NT) and replace later.
- Meqabyan 2 & 3 may require licensed English texts with verse numbering; format is the same.
